package com.example.Spring_boot_microservice.service.serviceImpl;

import com.example.Spring_boot_microservice.entity.Product;
import com.example.Spring_boot_microservice.repository.ProductRepository;
import com.example.Spring_boot_microservice.service.ProductService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    ProductRepository productRepository;

    @Override
    public Product save(Product product) {
        product=productRepository.save(product);
        return product;
    }

    @Override
    public List<Product> getAllDetails() {
        return productRepository.findAll();
    }

    @Override
    public Product getbyName(String name) {
        Optional<Product>optional=productRepository.findByName(name);
        if (optional.isPresent()){
            Product product=optional.get();

        }
        return optional.get();
    }

    @Override
    public Product getbyId(Long productId) {
        Optional<Product>optionalProduct=productRepository.findById(productId);
        if (optionalProduct.isPresent()){
            Product product=optionalProduct.get();

        }
        return optionalProduct.get();
    }

    @Override
    public Product DeleteByProductDetails(Long productId) {
        Optional<Product>optionalProduct=productRepository.findById(productId);
        if (optionalProduct.isPresent()){
            Product product=optionalProduct.get();
            productRepository.delete(product);

        }
        return optionalProduct.get();
    }

    @Override
    public Product updateProductDetails(Product product) {
        Optional<Product>optionalProduct=productRepository.findById(product.getProductId());
        if (optionalProduct.isPresent()){
            Product product1=optionalProduct.get();
            product1.setProductId(product.getProductId());
            product1.setActive(product.getActive());
            product1.setBrand(product.getBrand());
            product1.setCategory(product.getCategory());
            product1.setDescription(product.getDescription());
            product1.setImageUrl(product.getImageUrl());
            product1.setPrice(product.getPrice());
            product1.setName(product.getName());
            product1.setStockQuantity(product.getStockQuantity());
            product1.setSku(product.getSku());
            productRepository.save(product1);

        }
        return optionalProduct.get();
    }

    @Override
    public Product productByDetails(Long productId, Product product) {
        Optional<Product> optionalProduct = productRepository.findById(productId);
        if (optionalProduct.isPresent()) {
            Product product1 = optionalProduct.get();
            product1.setProductId(product.getProductId());
            product1.setActive(product.getActive());
            product1.setBrand(product.getBrand());
            product1.setCategory(product.getCategory());
            product1.setDescription(product.getDescription());
            product1.setImageUrl(product.getImageUrl());
            product1.setPrice(product.getPrice());
            product1.setName(product.getName());
            product1.setStockQuantity(product.getStockQuantity());
            product1.setSku(product.getSku());

            return productRepository.save(product1);
        } else {
            // Throw a custom exception if product is not found
            throw new EntityNotFoundException("Product not found with id: " + productId);
        }
    }


}

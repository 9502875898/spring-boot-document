package com.example.Spring_boot_microservice.service;

import com.example.Spring_boot_microservice.entity.Customer;

import java.util.List;

public interface CustomerService {
    Customer save(Customer customer);

    List<Customer> getAllDetails();

    Customer getByCustomerId(Long customerId);

    Customer getByCustomerName(String customerName);

    Customer updateAllCustomerDetails(Customer customer);

    Customer deleteByCustomerId(Long customerId);
}

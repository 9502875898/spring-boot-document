package com.example.Spring_boot_microservice.controller;

import com.example.Spring_boot_microservice.entity.Product;
import com.example.Spring_boot_microservice.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/product")
public class ProductController {
    @Autowired
    ProductService productService;
    @PostMapping("/save")
    public Product saveProductDetails(@RequestBody Product product){
        return productService.save(product);
    }
    @GetMapping("/getAll")
    public List<Product>getAllProduct(){
        return productService.getAllDetails();
    }
    @GetMapping("/productId/{productId}")
    public Product getbyId(@PathVariable Long productId){
        return productService.getbyId(productId);
    }
    @GetMapping("/name/{name}")
    public Product getbyName(@PathVariable String name){
        return productService.getbyName(name);
    }
    @DeleteMapping("/productId/{productId}")
    public Product DeleteByProductDetails(@PathVariable Long productId ){
        return productService.DeleteByProductDetails(productId);
    }
    @PutMapping("/update")
    public Product updateProductDetails(@RequestBody Product product){
        return productService.updateProductDetails(product);
    }
    @PatchMapping("/productId/{productId}")
    public Object updateByDetails(@PathVariable Long productId, @RequestBody Product product) {
        try {
            Product updatedProduct = productService.productByDetails(productId, product);
            return ResponseEntity.ok(updatedProduct); // Return the updated product
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // Return 404 if product is not found
        }
    }

}

package com.example.Spring_boot_microservice.service;

import com.example.Spring_boot_microservice.entity.Payment;

import java.util.List;

public interface PaymentService {
    Payment save(Payment payment);

    List<Payment> getAlldetails();

    Payment getAmount(Double amount);

    Payment getById(Long paymentId);

    Payment deleteByPaymentDetails(Long paymentId);

    Payment updatePaymentDetails(Payment payment);

    Payment getUpdatePathDetails(Long paymentId, Payment payment);
}

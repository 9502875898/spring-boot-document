package com.example.Spring_boot_microservice.controller;

import com.example.Spring_boot_microservice.entity.Customer;
import com.example.Spring_boot_microservice.entity.Payment;
import com.example.Spring_boot_microservice.service.CustomerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customer")
@Slf4j
public class CustomerController {
    @Autowired
    CustomerService customerService;
    @PostMapping("/save")
    public Customer saveCustomerDetails(@RequestBody Customer customer){
        return customerService.save(customer);
    }
    @GetMapping("/getAll")
    public List<Customer>getAllcustomerDetails(){
        return customerService.getAllDetails();
    }
    @GetMapping("/customerId/{customerId}")
    public Customer getByIdDetails(@PathVariable Long customerId){
        return customerService.getByCustomerId(customerId);
    }
    @GetMapping("/customerName/{customerName}")
    public Customer getByCustomerName(@PathVariable String customerName){
        return customerService.getByCustomerName(customerName);
    }
    @PutMapping("/update")
    public Customer updateAllCustomerDetails(@RequestBody Customer customer){
        return customerService.updateAllCustomerDetails(customer);
    }
    @DeleteMapping("/customerId/{customerId}")
    public Customer deleteByCustomerId(@PathVariable Long customerId){
        return customerService.deleteByCustomerId(customerId);
    }
}

package com.example.Spring_boot_microservice.service;

import com.example.Spring_boot_microservice.entity.Product;

import java.util.List;

public interface ProductService {
    Product save(Product product);

    List<Product> getAllDetails();

    Product getbyName(String name);

    Product getbyId(Long productId);

    Product DeleteByProductDetails(Long productId);

    Product updateProductDetails(Product product);

    Product productByDetails(Long productId, Product product);
}

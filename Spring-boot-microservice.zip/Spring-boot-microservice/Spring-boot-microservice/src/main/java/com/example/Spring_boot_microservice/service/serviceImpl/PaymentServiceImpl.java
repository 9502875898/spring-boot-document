package com.example.Spring_boot_microservice.service.serviceImpl;

import com.example.Spring_boot_microservice.entity.Payment;
import com.example.Spring_boot_microservice.repository.PaymentRepository;
import com.example.Spring_boot_microservice.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PaymentServiceImpl implements PaymentService {
    @Autowired
    PaymentRepository paymentRepository;

    @Override
    public Payment save(Payment payment) {

        return paymentRepository.save(payment);
    }

    @Override
    public List<Payment> getAlldetails() {
        return paymentRepository.findAll();
    }

    @Override
    public Payment getAmount(Double amount) {
        Optional<Payment>optionalPayment=paymentRepository.findByAmount(amount);
        if (optionalPayment.isPresent()){
            Payment payment=optionalPayment.get();
        }
        return optionalPayment.get();
    }

    @Override
    public Payment getById(Long paymentId) {
        Optional<Payment>optionalPayment=paymentRepository.findById(paymentId);
        if (optionalPayment.isPresent()){
            Payment payment=optionalPayment.get();
        }
        return optionalPayment.get();

    }

    @Override
    public Payment deleteByPaymentDetails(Long paymentId) {
        Optional<Payment>optionalPayment=paymentRepository.findById(paymentId);
        if (optionalPayment.isPresent()){
            Payment payment=optionalPayment.get();
            paymentRepository.delete(payment);
        }
        return optionalPayment.get();
    }

    @Override
    public Payment updatePaymentDetails(Payment payment) {
        Optional<Payment>optionalPayment=paymentRepository.findById(payment.getPaymentId());
        if (optionalPayment.isPresent()){
            Payment payment1=optionalPayment.get();
            payment1.setPaymentId(payment.getPaymentId());
            payment1.setCurrency(payment.getCurrency());
            payment1.setStatus(payment.getStatus());
            payment1.setAmount(payment.getAmount());


            paymentRepository.delete(payment1);
        }
        return optionalPayment.get();
    }

    @Override
    public Payment getUpdatePathDetails(Long paymentId, Payment payment) {
        Optional<Payment> optionalPayment = paymentRepository.findById(paymentId);
        if (optionalPayment.isPresent()) {
            Payment existingPayment = optionalPayment.get();

            // Update the values in the 'payment' object with existing ones, or adjust as needed.
            payment.setPaymentId(existingPayment.getPaymentId()); // Use existing PaymentId
            payment.setCurrency(existingPayment.getCurrency()); // Preserve currency
            payment.setStatus(existingPayment.getStatus()); // Preserve status
            payment.setAmount(existingPayment.getAmount()); // Preserve amount

            // Save the updated payment
            return paymentRepository.save(payment); // Return the saved (updated) payment
        }

        // If paymentId is not found, return null or throw an exception based on your business logic
        return null; // Or throw an exception if you prefer
    }
    }


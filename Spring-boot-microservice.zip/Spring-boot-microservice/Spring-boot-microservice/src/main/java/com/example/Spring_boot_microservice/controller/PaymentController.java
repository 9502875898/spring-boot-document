package com.example.Spring_boot_microservice.controller;

import com.example.Spring_boot_microservice.entity.Payment;
import com.example.Spring_boot_microservice.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/payment")
public class PaymentController {
    @Autowired
    PaymentService paymentService;

    @PostMapping("/save")
    public Payment savePaymentDetails(@RequestBody Payment payment) {
        return paymentService.save(payment);
    }
    @GetMapping("/getAll")
    public List<Payment>getAllPayment(){
        return paymentService.getAlldetails();
    }
    @GetMapping("/amount/{amount}")
    public Payment getAmount(@PathVariable Double amount){
        return paymentService.getAmount(amount);
    }
    @GetMapping("/paymentId/{paymentId}")
    public Payment getById(@PathVariable Long paymentId){
        return paymentService.getById(paymentId);
    }
    @DeleteMapping("/paymentId/{paymentId}")
    public Payment deleteByPaymentDetails(@PathVariable Long paymentId){
        return paymentService.deleteByPaymentDetails(paymentId);
    }
    @PutMapping("/update")
    public Payment updatePaymentDetails(@RequestBody Payment payment){
        return paymentService.updatePaymentDetails(payment);
    }
    @PatchMapping("/paymentId/{paymentId}")
    public Payment getUpdatePathDetails(@PathVariable Long paymentId,@RequestBody Payment payment){
        return paymentService.getUpdatePathDetails(paymentId,payment);
    }
}

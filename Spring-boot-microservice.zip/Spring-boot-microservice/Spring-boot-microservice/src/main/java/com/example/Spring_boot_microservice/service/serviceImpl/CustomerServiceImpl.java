package com.example.Spring_boot_microservice.service.serviceImpl;

import com.example.Spring_boot_microservice.entity.Customer;
import com.example.Spring_boot_microservice.repository.CustomerRepository;
import com.example.Spring_boot_microservice.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    CustomerRepository customerRepository;

    @Override
    public Customer save(Customer customer) {

        return customerRepository.save(customer);
    }

    @Override
    public List<Customer> getAllDetails() {
        return customerRepository.findAll();
    }

    @Override
    public Customer getByCustomerId(Long customerId) {
        Optional<Customer>optionalCustomer=customerRepository.findById(customerId);
        if (optionalCustomer.isPresent()){
            Customer customer=optionalCustomer.get();
        }
        return optionalCustomer.get();
    }

    @Override
    public Customer getByCustomerName(String customerName) {
        Optional<Customer>optionalCustomer=customerRepository.findByCustomerName(customerName);
        if (optionalCustomer.isPresent()){
            Customer customer=optionalCustomer.get();
        }
        return optionalCustomer.get();
    }

    @Override
    public Customer updateAllCustomerDetails(Customer customer) {
        Optional<Customer>optionalCustomer=customerRepository.findById(customer.getCustomerId());
        if (optionalCustomer.isPresent()){
         Customer  customer1=optionalCustomer.get();
         customer1.setCustomerId(customer.getCustomerId());
         customer1.setCustomerName(customer.getCustomerName());
         customer1.setCustomerDateOfBirt(customer.getCustomerDateOfBirt());
         customer1.setAddress(customer.getAddress());
         customer1.setPhoneNumber(customer.getPhoneNumber());
         customer1.setProducts(customer.getProducts());

           customerRepository.save(customer1);
        }
        return optionalCustomer.get();
    }

    @Override
    public Customer deleteByCustomerId(Long customerId) {
        Optional<Customer>optionalCustomer=customerRepository.findById(customerId);
        if (optionalCustomer.isPresent()){
            Customer customer=optionalCustomer.get();
            customerRepository.delete(customer);
        }
        return optionalCustomer.get();
    }
}

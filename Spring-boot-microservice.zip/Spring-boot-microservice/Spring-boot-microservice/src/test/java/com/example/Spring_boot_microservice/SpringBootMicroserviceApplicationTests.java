package com.example.Spring_boot_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
